/* Dhruvo Sangsad — application core. No framework. */
const DB_NAME="DhruvoSangsadDB", DB_VER=1;
const stores=["members","deposits","notifications","activityLogs","settings","syncQueue"];
let db, session=null, online=navigator.onLine;

const $=s=>document.querySelector(s);
const today=()=>{const d=new Date();return String(d.getDate()).padStart(2,"0")+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+d.getFullYear()};
const isoToday=()=>new Date().toISOString().slice(0,10);
const money=n=>Number(n||0).toLocaleString("en-BD",{minimumFractionDigits:2,maximumFractionDigits:2});
const id=()=>crypto.randomUUID?crypto.randomUUID():Date.now()+"-"+Math.random().toString(36).slice(2);
const norm=s=>String(s||"").trim().toLowerCase();
const role=(u)=>u?.role||"";

function openDB(){return new Promise((res,rej)=>{const r=indexedDB.open(DB_NAME,DB_VER);r.onupgradeneeded=e=>{const d=e.target.result;stores.forEach(s=>{if(!d.objectStoreNames.contains(s)){const o=d.createObjectStore(s,{keyPath:"id"});if(s==="members"){o.createIndex("mobile","mobile",{unique:false});o.createIndex("memberId","memberId",{unique:false})}if(s==="deposits"){o.createIndex("memberId","memberId",{unique:false});o.createIndex("date","date",{unique:false})}}});};r.onsuccess=()=>{db=r.result;res(db)};r.onerror=()=>rej(r.error)})}
function put(store,v){return new Promise((res,rej)=>{const t=db.transaction(store,"readwrite");t.objectStore(store).put(v);t.oncomplete=()=>res(v);t.onerror=()=>rej(t.error)})}
function del(store,k){return new Promise((res,rej)=>{const t=db.transaction(store,"readwrite");t.objectStore(store).delete(k);t.oncomplete=()=>res();t.onerror=()=>rej(t.error)})}
function all(store){return new Promise((res,rej)=>{const r=db.transaction(store).objectStore(store).getAll();r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})}
async function one(store,k){return new Promise((res,rej)=>{const r=db.transaction(store).objectStore(store).get(k);r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})}
async function queue(op,payload){await put("syncQueue",{id:id(),createdAt:Date.now(),op,payload,status:"pending"});}

function toast(s){let x=document.createElement("div");x.className="toast";x.textContent=s;document.body.appendChild(x);setTimeout(()=>x.remove(),2500)}
function fmtInputDate(v){if(!v)return ""; if(/^\\d{2}-\\d{2}-\\d{4}$/.test(v))return v; const [y,m,d]=v.split("-"); return `${d}-${m}-${y}`}
function parseDMY(s){const [d,m,y]=String(s).split("-").map(Number);return new Date(y,m-1,d)}
function calc(member, deposits){let total=deposits.filter(x=>x.memberId===member.memberId&&x.status==="approved").reduce((a,x)=>a+Number(x.amount||0),0);const start=new Date(parseDMY(member.approvedAt||today()));const now=new Date();let months=(now.getFullYear()-start.getFullYear())*12+(now.getMonth()-start.getMonth())+1;if(months<0)months=0;let required=Math.max(0,months*Number(member.monthlyInstallment||0));let due=Math.max(0,required-total), advance=Math.max(0,total-required);return {total,due,advance,required}}
async function log(action,details=""){if(!session)return;await put("activityLogs",{id:id(),user:session.username,role:session.role,action,details,date:today(),time:new Date().toLocaleTimeString()})}

function renderLogin(){document.body.innerHTML=`<div class="login"><div class="login-card"><div class="brand">ধ্রুব সংসদ</div><div class="sub">Offline-first Member & Deposit Management</div><form id="loginForm"><div class="field"><label>User ID / Mobile Number</label><input id="uid" required autocomplete="username"></div><div class="field"><label>Password</label><input id="pw" type="password" required autocomplete="current-password"></div><button class="primary" style="width:100%">Login / লগইন</button></form><button class="neutral" id="reg" style="width:100%;margin-top:8px">Member Registration</button><button class="neutral" id="forgot" style="width:100%;margin-top:8px">Forgot Password</button><div class="notice" style="margin-top:12px">First installation bootstrap: <b>admin / admin</b>. Change it immediately in Admin Setup.</div></div></div>`;
$("#loginForm").onsubmit=async e=>{e.preventDefault();await login($("#uid").value,$("#pw").value)};
$("#reg").onclick=()=>renderRegistration(); $("#forgot").onclick=()=>toast("Password recovery requires your configured Firebase Authentication flow.")}

async function login(uid,pw){
 const members=await all("members"); let m=members.find(x=>x.mobile===uid&&x.localPassword===pw);
 if(uid==="admin"&&pw==="admin"){session={username:"admin",role:"ADMIN",first:true};await log("Login","Bootstrap admin");renderApp();return}
 let maker=members.find(x=>x.type==="maker"&&x.username===uid&&x.localPassword===pw&&x.status==="active");
 if(maker){session={username:maker.username,role:"MAKER",makerId:maker.id};await log("Login");renderApp();return}
 if(m){session={username:m.memberId,role:"MEMBER",memberId:m.memberId};await log("Login");renderApp();return}
 toast("User ID বা Password সঠিক নয়।");
}

function navButtons(){
 let r=role(session);let a=[["home","⌂ Home"],["members","👥 Members"],["deposit","💰 Deposit"],["history","▤ Deposit History"],["reports","▥ Reports"],["notifications","🔔 Notifications"],["activity","▤ Activity Log"]];
 if(r==="ADMIN")a.push(["admin","⚙ Admin Panel"],["backup","↥ Backup & Restore"],["settings","⚙ Settings"]);
 if(r==="MAKER")a.push(["maker","🛠 Maker Panel"]);
 if(r==="MEMBER")a=[["home","⌂ Home"],["profile","👤 My Profile"],["deposit","💰 Deposit"],["history","▤ My History"],["reports","▥ My Statement"],["settings","⚙ Settings"]];
 return a;
}
function renderApp(){
 document.body.innerHTML=`<div class="topbar"><div><button id="menu" class="neutral">☰</button> <strong>ধ্রুব সংসদ</strong></div><div class="userbox"><span>${session.username} · ${session.role}</span><button id="logout" class="danger">Logout</button></div></div><div class="layout"><aside id="side">${navButtons().map(([k,t])=>`<button data-nav="${k}">${t}</button>`).join("")}</aside><main class="main" id="main"></main></div>`;
 $("#logout").onclick=async()=>{await log("Logout");session=null;renderLogin()};
 $("#menu").onclick=()=>$("#side").classList.toggle("open");
 document.querySelectorAll("[data-nav]").forEach(b=>b.onclick=()=>{$("#side").classList.remove("open");route(b.dataset.nav)});
 route("home");
 if("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(()=>{});
}
async function route(k){
 if(k==="home")return dashboard();
 if(k==="members")return memberList();
 if(k==="profile")return profile();
 if(k==="deposit")return depositForm();
 if(k==="history")return history();
 if(k==="reports")return reports();
 if(k==="notifications")return notifications();
 if(k==="activity")return activity();
 if(k==="admin")return adminPanel();
 if(k==="maker")return makerPanel();
 if(k==="backup")return backup();
 if(k==="settings")return settings();
}

async function dashboard(){
 const ms=await all("members"), ds=await all("deposits"), approved=ds.filter(x=>x.status==="approved");
 let total=approved.reduce((a,x)=>a+Number(x.amount||0),0), due=0,adv=0;
 for(const m of ms.filter(x=>x.status==="active")){const c=calc(m,ds);due+=c.due;adv+=c.advance}
 $("#main").innerHTML=`<div class="section-title">Dashboard</div><div class="grid"><div class="card">👥 Total Members<div class="metric">${ms.filter(x=>x.type!=="maker").length}</div></div><div class="card">💰 Total Deposit<div class="metric">৳ ${money(total)}</div></div><div class="card">⚠️ Total Due<div class="metric">৳ ${money(due)}</div></div><div class="card">⬆️ Total Advance<div class="metric">৳ ${money(adv)}</div></div><div class="card">⏳ Pending Approval<div class="metric">${ms.filter(x=>x.status==="pending").length+ds.filter(x=>x.status==="pending").length}</div></div><div class="card">📅 Today's Collection<div class="metric">৳ ${money(approved.filter(x=>x.date===today()).reduce((a,x)=>a+Number(x.amount||0),0))}</div></div></div><div class="card" style="margin-top:10px"><b>Today's Activity</b><div id="todayAct" class="muted">Loading...</div></div>`;
 const logs=await all("activityLogs");$("#todayAct").innerHTML=logs.filter(x=>x.date===today()).slice(-8).reverse().map(x=>`${x.time} — ${x.user}: ${x.action}`).join("<br>")||"No activity";
}
async function renderRegistration(){
 $("#app").innerHTML=`<div class="login"><div class="login-card" style="max-width:720px"><div class="brand">Member Registration</div><form id="rf"><div class="form-grid">
${[
["nameBn","Name (Bangla) *"],["nameEn","Name (English) *"],["fatherBn","Father's Name (Bangla)"],["fatherEn","Father's Name (English)"],["motherBn","Mother's Name (Bangla)"],["motherEn","Mother's Name (English)"],["mobile","Mobile Number *"],["whatsapp","WhatsApp Number *"],["email","Email ID"],["nid","NID Number"],["dob","Date of Birth (DD-MM-YYYY)"],["profession","Profession"],["address","Address"],["monthlyInstallment","Monthly Installment *"],["password","Password *"]
].map(([i,l])=>`<div class="field"><label>${l}</label><input id="${i}" ${i==="password"?"type=password":""} ${i==="monthlyInstallment"?"type=number min=0 step=0.01":""} required></div>`).join("")}</div><div class="actions"><button class="primary">Register</button><button type="button" class="neutral" id="back">Back to Login</button></div></form></div></div>`;
 $("#back").onclick=renderLogin;
 $("#rf").onsubmit=async e=>{e.preventDefault();const g=i=>$("#"+i).value.trim();let mobile=g("mobile"),mid=mobile.slice(-6);if(mobile.length<6)return toast("সঠিক Mobile Number দিন।");let ms=await all("members");if(ms.some(x=>x.memberId===mid))return toast("এই Member ID ইতোমধ্যে ব্যবহৃত হয়েছে।");if(ms.some(x=>x.mobile===mobile))return toast("এই মোবাইল নম্বর ইতোমধ্যে একজন সদস্যের জন্য ব্যবহৃত হয়েছে।");if(ms.some(x=>x.whatsapp===g("whatsapp")))return toast("এই WhatsApp নম্বর ইতোমধ্যে ব্যবহৃত হয়েছে।");if(g("email")&&ms.some(x=>norm(x.email)===norm(g("email"))))return toast("এই Email ID ইতোমধ্যে ব্যবহৃত হয়েছে।");
let m={id:id(),type:"member",memberId:mid,nameBn:g("nameBn"),nameEn:g("nameEn"),fatherBn:g("fatherBn"),fatherEn:g("fatherEn"),motherBn:g("motherBn"),motherEn:g("motherEn"),mobile,whatsapp:g("whatsapp"),email:g("email"),nid:g("nid"),dob:g("dob"),profession:g("profession"),address:g("address"),monthlyInstallment:Number(g("monthlyInstallment")),localPassword:g("password"),status:"pending",createdAt:Date.now(),updatedAt:Date.now()};
await put("members",m);await queue("createMember",m);toast("Registration Successful");setTimeout(()=>renderLogin(),700)}}

async function memberList(){
 let ms=(await all("members")).filter(x=>x.type!=="maker"),ds=await all("deposits");
 if(role(session)==="MEMBER")ms=ms.filter(x=>x.memberId===session.memberId);
 $("#main").innerHTML=`<div class="section-title">Member Search</div><div class="card"><div class="field"><input id="q" placeholder="Member ID / Name / Mobile / WhatsApp"></div></div><div class="table-wrap" style="margin-top:8px"><table class="table"><thead><tr><th>ID</th><th>Name</th><th>Mobile</th><th>Installment</th><th>Status</th><th>Action</th></tr></thead><tbody id="mt"></tbody></table></div>`;
 const paint=()=>{$("#mt").innerHTML=ms.filter(m=>{let q=norm($("#q").value);return !q||[m.memberId,m.nameBn,m.nameEn,m.mobile,m.whatsapp].some(v=>norm(v).includes(q))}).map(m=>{let c=calc(m,ds);return `<tr><td>${m.memberId}</td><td>${m.nameBn}<br>${m.nameEn}</td><td>${m.mobile}</td><td>৳${money(m.monthlyInstallment)}</td><td><span class="badge ${m.status}">${m.status}</span></td><td>${role(session)!=="MEMBER"?`<button class="neutral" onclick="approveMember('${m.id}','${m.status}')">${m.status==="pending"?"Approve":"Edit"}</button>`:"View"}</td></tr>`}).join("")||"<tr><td colspan=6>No data</td></tr>"};
$("#q").oninput=paint;paint();
}
window.approveMember=async(id,status)=>{let m=await one("members",id);if(!m)return;if(status==="pending"){m.status="active";m.approvedAt=today();m.updatedAt=Date.now();await put("members",m);await queue("updateMember",m);await log("Member Approval",m.memberId);toast("Member Approved");memberList()}else toast("Member editing can be extended from Admin/Maker workflow.")}

async function depositForm(){
 let ms=await all("members");if(role(session)==="MEMBER")ms=ms.filter(x=>x.memberId===session.memberId&&x.status==="active");
 if(role(session)==="MEMBER"&&ms.length===0){$("#main").innerHTML=`<div class="notice">Pending/Rejected member cannot submit deposit. Active approval required.</div>`;return}
 $("#main").innerHTML=`<div class="section-title">অর্থ ব্যবস্থাপনা / Deposit</div><div class="card"><form id="df"><div class="form-grid"><div class="field"><label>Member</label><select id="dm">${ms.map(m=>`<option value="${m.memberId}">${m.memberId} — ${m.nameBn}</option>`).join("")}</select></div><div class="field"><label>Deposit Date</label><input id="dd" value="${today()}"></div><div class="field"><label>Deposit Type</label><select id="dt"><option>মাসিক জমা</option><option>অগ্রিম জমা</option><option>বিশেষ চাঁদা</option><option>অন্যান্য</option></select></div><div class="field"><label>Description</label><input id="desc"></div><div class="field"><label>Deposit Amount</label><input id="amt" type="number" min="0.01" step="0.01" required></div><div class="field"><label>Payment Method</label><select id="pm"><option>Cash</option><option>Mobile Banking</option><option>Bank</option></select></div><div class="field"><label>Comment / Note</label><input id="note"></div></div><div id="minfo" class="notice"></div><div class="actions"><button class="primary">Save</button><button type="reset" class="neutral">Clear</button></div></form></div>`;
 const update=async()=>{let m=ms.find(x=>x.memberId===$("#dm").value);let c=m?calc(m,await all("deposits")):{total:0,due:0,advance:0};$("#minfo").innerHTML=m?`Member: <b>${m.nameBn}</b> · Installment ৳${money(m.monthlyInstallment)} · Total ৳${money(c.total)} · Due ৳${money(c.due)} · Advance ৳${money(c.advance)}`:""};
$("#dm").onchange=update;await update();
$("#df").onsubmit=async e=>{e.preventDefault();let m=ms.find(x=>x.memberId===$("#dm").value);let type=$("#dt").value;if((type==="বিশেষ চাঁদা"||type==="অন্যান্য")&&!$("#desc").value.trim())return toast("Description required");let d={id:id(),memberId:m.memberId,memberName:m.nameBn,date:$("#dd").value||today(),type,description:$("#desc").value.trim(),amount:Number($("#amt").value),paymentMethod:$("#pm").value,note:$("#note").value.trim(),submittedBy:session.username,submittedAt:Date.now(),status:role(session)==="MEMBER"?"pending":"approved"};await put("deposits",d);await queue("createDeposit",d);await log("Deposit Submission",`${d.memberId} ৳${d.amount}`);alert(`Deposit ${d.status==="approved"?"Saved":"Submitted Successfully"}\\nAmount: ৳${money(d.amount)}\\nStatus: ${d.status}`);e.target.reset();$("#dd").value=today();await update()}}
}

async function history(){
 let ds=await all("deposits"),ms=await all("members");if(role(session)==="MEMBER")ds=ds.filter(x=>x.memberId===session.memberId);
 $("#main").innerHTML=`<div class="section-title">Deposit History</div><div class="table-wrap"><table class="table"><thead><tr><th>SL</th><th>Date</th><th>Member</th><th>Type</th><th>Method</th><th>Amount</th><th>Status</th><th>Action</th></tr></thead><tbody id="ht"></tbody></table></div>`;
 let cumul={};ds.sort((a,b)=>parseDMY(a.date)-parseDMY(b.date));$("#ht").innerHTML=ds.map((d,i)=>{cumul[d.memberId]=(cumul[d.memberId]||0)+(d.status==="approved"?Number(d.amount):0);return `<tr><td>${i+1}</td><td>${d.date}</td><td>${d.memberId} — ${d.memberName}</td><td>${d.type}</td><td>${d.paymentMethod}</td><td>৳${money(d.amount)}</td><td><span class="badge ${d.status}">${d.status}</span></td><td>${d.status==="pending"&&role(session)!=="MEMBER"?`<button class="primary" onclick="approveDeposit('${d.id}',true)">Approve</button> <button class="danger" onclick="approveDeposit('${d.id}',false)">Reject</button>`:""}</td></tr>`}).join("")||"<tr><td colspan=8>No data</td></tr>";
}
window.approveDeposit=async(id,ok)=>{let d=await one("deposits",id);if(!d)return;d.status=ok?"approved":"rejected";d.reviewedBy=session.username;d.reviewedAt=Date.now();await put("deposits",d);await queue("updateDeposit",d);await log(ok?"Deposit Approval":"Deposit Rejection",d.memberId);toast(ok?"Deposit Approved":"Deposit Rejected");history()}

async function reports(){
 let ms=(await all("members")).filter(x=>x.type==="member"&&x.status!=="rejected"),ds=await all("deposits");if(role(session)==="MEMBER")ms=ms.filter(x=>x.memberId===session.memberId);
 let rows=ms.map(m=>({m,c:calc(m,ds)}));$("#main").innerHTML=`<div class="section-title">Overall Report</div><div class="actions"><button class="neutral" id="csv">CSV</button><button class="neutral" id="pdf">Download PDF</button><button class="neutral" id="clear">Clear</button></div><div class="table-wrap"><table class="table" id="rt"><thead><tr><th>Member Name</th><th>Monthly Installment</th><th>Total Deposit</th><th>Total Due</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${r.m.nameBn}</td><td>৳${money(r.m.monthlyInstallment)}</td><td>৳${money(r.c.total)}</td><td>৳${money(r.c.due)}</td></tr>`).join("")}</tbody><tfoot><tr><th>Total</th><th></th><th>৳${money(rows.reduce((a,r)=>a+r.c.total,0))}</th><th>৳${money(rows.reduce((a,r)=>a+r.c.due,0))}</th></tr></tfoot></table></div>`;
$("#csv").onclick=()=>downloadCSV(rows);$("#pdf").onclick=()=>printReport(rows);$("#clear").onclick=()=>route("reports")}
function downloadCSV(rows){let s="Member Name,Monthly Installment,Total Deposit,Total Due\\n"+rows.map(r=>[r.m.nameBn,r.m.monthlyInstallment,r.c.total,r.c.due].map(v=>`"${String(v).replaceAll('"','""')}"`).join(",")).join("\\n");let a=document.createElement("a");a.href=URL.createObjectURL(new Blob(["\\ufeff"+s],{type:"text/csv;charset=utf-8"}));a.download="Dhruvo_Sangsad_Overall_Report.csv";a.click()}
function printReport(rows){let w=window.open("","_blank");if(!w){toast("Popup blocked");return}w.document.write(`<html><head><title>Dhruvo Sangsad Report</title><style>body{font-family:Arial,"Noto Sans Bengali";font-size:10px}table{border-collapse:collapse;width:100%}th,td{border:1px solid #222;padding:4px}h2{font-size:13px}</style></head><body><h2>ধ্রুব সংসদ — Overall Report</h2><table><tr><th>Member Name</th><th>Monthly Installment</th><th>Total Deposit</th><th>Total Due</th></tr>${rows.map(r=>`<tr><td>${r.m.nameBn}</td><td>${r.c.required/r.c.required* r.m.monthlyInstallment}</td><td>${r.c.total}</td><td>${r.c.due}</td></tr>`).join("")}</table><script>window.onload=()=>window.print()<\\/script></body></html>`);w.document.close()}

async function profile(){let m=await one("members",(await all("members")).find(x=>x.memberId===session.memberId)?.id);if(!m)return;$("#main").innerHTML=`<div class="section-title">My Profile</div><div class="card"><div class="form-grid">${Object.entries({MemberID:m.memberId,"Name (Bangla)":m.nameBn,"Name (English)":m.nameEn,Father:m.fatherBn,Mother:m.motherBn,Mobile:m.mobile,WhatsApp:m.whatsapp,Email:m.email,NID:m.nid,"Date of Birth":m.dob,Profession:m.profession,Address:m.address,"Monthly Installment":"৳"+money(m.monthlyInstallment),Status:m.status}).map(([k,v])=>`<div><div class="muted">${k}</div><b>${v||"—"}</b></div>`).join("")}</div></div>`}
async function notifications(){let n=await all("notifications");$("#main").innerHTML=`<div class="section-title">Notifications</div><div class="card">${n.sort((a,b)=>b.createdAt-a.createdAt).map(x=>`<div style="padding:7px;border-bottom:1px solid #eee">${x.message}<div class="muted">${new Date(x.createdAt).toLocaleString()}</div></div>`).join("")||"No notifications"}</div>`}
async function activity(){let a=await all("activityLogs");$("#main").innerHTML=`<div class="section-title">Activity Log</div><div class="table-wrap"><table class="table"><tr><th>User</th><th>Role</th><th>Action</th><th>Date</th><th>Time</th></tr>${a.reverse().map(x=>`<tr><td>${x.user}</td><td>${x.role}</td><td>${x.action}</td><td>${x.date}</td><td>${x.time}</td></tr>`).join("")}</table></div>`}
async function adminPanel(){let ms=await all("members"), pendingM=ms.filter(x=>x.type==="member"&&x.status==="pending"),ds=await all("deposits"),pendingD=ds.filter(x=>x.status==="pending");$("#main").innerHTML=`<div class="section-title">Admin Panel</div><div class="grid"><div class="card"><b>Pending Members</b><div class="metric">${pendingM.length}</div></div><div class="card"><b>Pending Deposits</b><div class="metric">${pendingD.length}</div></div></div><div class="card" style="margin-top:8px"><b>Bootstrap password</b><p class="muted">The requested admin/admin credential is local bootstrap only. Change it by implementing Firebase Authentication credentials before production deployment.</p></div>`}
async function makerPanel(){await memberList()}
async function backup(){let data={members:await all("members"),deposits:await all("deposits"),notifications:await all("notifications"),activityLogs:await all("activityLogs"),settings:await all("settings")};$("#main").innerHTML=`<div class="section-title">Backup & Restore</div><div class="card"><button class="primary" id="b">Download Backup</button><input id="restore" type="file" accept=".json" style="margin-left:8px"><button class="danger" id="r">Restore</button><div class="notice">Restore replaces local IndexedDB data. Use only a trusted backup.</div></div>`;$("#b").onclick=()=>{let a=document.createElement("a");a.href=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:"application/json"}));a.download="Dhruvo_Sangsad_Backup.json";a.click();log("Backup")};$("#r").onclick=async()=>{if(!confirm("Restore backup?"))return;let f=$("#restore").files[0];if(!f)return toast("Select backup");let x=JSON.parse(await f.text());for(const s of stores.slice(0,5))for(const v of x[s]||[])await put(s,v);await log("Restore");toast("Restore complete");route("home")}}
async function settings(){$("#main").innerHTML=`<div class="section-title">Settings</div><div class="card"><p>Connection: <b>${online?"Online":"Offline"}</b></p><p class="muted">Firebase configuration is read from firebase-config.js. IndexedDB remains the local operational store.</p><button class="neutral" onclick="location.reload()">Reload</button></div>`}

async function init(){await openDB();renderLogin();window.addEventListener("online",()=>{online=true;toast("Online");syncQueue()});window.addEventListener("offline",()=>{online=false;toast("Offline mode")});}
async function syncQueue(){if(!online)return;let q=await all("syncQueue");if(!q.length)return;/* Firebase adapter hook: records stay queued until Firebase is configured. */for(const x of q){x.status="waiting-firebase";await put("syncQueue",x)}}
init();