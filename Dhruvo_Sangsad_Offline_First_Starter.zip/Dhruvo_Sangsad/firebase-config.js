/* Fill these values from Firebase Console.
   The app works locally with IndexedDB even before Firebase is configured. */
window.DHRUVO_FIREBASE_CONFIG = {
  apiKey: "",
  authDomain: "",
  databaseURL: "",
  projectId: "",
  storageBucket: "",
  messagingSenderId: "",
  appId: ""
};
