# ধ্রুব সংসদ — Offline-first Firebase-ready application

## Included
- Guest-only login screen
- Admin / Maker / Member role model
- Member registration and approval
- Deposit submission/approval
- Due/advance calculation
- Reports and CSV export
- Browser-print PDF workflow
- WhatsApp due reminder
- IndexedDB local database
- Offline sync queue
- PWA service worker
- Firebase configuration hook

## Important Firebase setup
Edit `firebase-config.js` with your Firebase Web App configuration.

Enable:
- Authentication → Email/Password
- Realtime Database

Create Firebase Security Rules appropriate to your deployment.

### Bootstrap admin
The requested `admin / admin` bootstrap is handled locally as a first-install bootstrap credential so the application can start offline. Firebase Authentication itself requires a password of at least 6 characters, so the literal `admin` password cannot be used as a Firebase Email/Password credential. On first setup, change the local bootstrap password and configure a real Firebase admin account.

## Run
For service-worker/PWA behavior, serve this folder from a local HTTP server rather than opening `index.html` directly.
Example:
`python -m http.server 8080`

Then open:
`http://localhost:8080`

The UI and IndexedDB work without internet after the app has been cached.
